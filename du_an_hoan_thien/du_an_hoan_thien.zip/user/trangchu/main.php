<?php ?>

<div class="content">
    <!-- ===== banner ====== -->
    <div class="banner d-none d-md-block">
        <div class="banner__img"></div>
    </div>

    <div class="container-fluid p-0">
        <div class="container block-content">
            <div class="content__section1">
                <div class="row">
                    <div class="col-12 col-lg-8 col-xl-8 section1-left">
                        <div class="content__section-header">
                            <div class="content__section-title title">Biên Tập Viên Đề Cử</div>
                            <a href="" class="content__section-link link">Xem Tất Cả</a>
                        </div>

                        <div class="content__section1-main">
                            <div class="row">
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <a href="HTML/product.html" class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/trach-nhat-phi-thang/150.jpg?1649217741" alt="">
                                        </a>
                                        <div class="content__section1-main-item-content">
                                            <a href="<?=$USER_URL?>/truyen/index.php?idTruyen=1" class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</a>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <a href="HTML/product.html" class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/trach-nhat-phi-thang/150.jpg?1649217741" alt="">
                                        </a>
                                        <div class="content__section1-main-item-content">
                                            <a href="HTML/product.html" class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</a>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <a href="HTML/product.html" class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/trach-nhat-phi-thang/150.jpg?1649217741" alt="">
                                        </a>
                                        <div class="content__section1-main-item-content">
                                            <a href="HTML/product.html" class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</a>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <a href="HTML/product.html" class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/trach-nhat-phi-thang/150.jpg?1649217741" alt="">
                                        </a>
                                        <div class="content__section1-main-item-content">
                                            <a href="HTML/product.html" class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</a>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <a href="HTML/product.html" class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/trach-nhat-phi-thang/150.jpg?1649217741" alt="">
                                        </a>
                                        <div class="content__section1-main-item-content">
                                            <a href="HTML/product.html" class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</a>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <a href="HTML/product.html" class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/trach-nhat-phi-thang/150.jpg?1649217741" alt="">
                                        </a>
                                        <div class="content__section1-main-item-content">
                                            <a href="HTML/product.html" class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</a>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <a href="HTML/product.html" class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/trach-nhat-phi-thang/150.jpg?1649217741" alt="">
                                        </a>
                                        <div class="content__section1-main-item-content">
                                            <a href="HTML/product.html" class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</a>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <a href="HTML/product.html" class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/trach-nhat-phi-thang/150.jpg?1649217741" alt="">
                                        </a>
                                        <div class="content__section1-main-item-content">
                                            <a href="HTML/product.html" class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</a>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 d-none d-lg-block section1-right">
                        <div class="content__section1-top">
                            <div class="content__section-header">
                                <div class="content__section-title title">Đang Đọc</div>
                                <a href="" class="content__section-link link">Xem Tất Cả</a>
                            </div>

                            <div class="content__section1-read">
                                <div class="content__section1-read-item">
                                    <div class="content__section1-read-img">
                                        <img src="https://static.cdnno.com/poster/dau-la-dai-luc-iv-chung-cuc-dau-la/150.jpg?1585206132" alt="">
                                    </div>
                                    <div class="content__section1-read-content">
                                        <div class="content__section1-main-item-title text">Bán Tiên</div>
                                        <div class="content__section1-read-chap">
                                            Đã Đọc: 12/615
                                            <i class="fas fa-trash"></i>
                                        </div>
                                    </div>
                                    <a href="" class="content__section1-read-continue">Đọc Tiếp</a>
                                </div>
                                <div class="content__section1-read-item">
                                    <div class="content__section1-read-img">
                                        <img src="https://static.cdnno.com/poster/dau-la-dai-luc-iv-chung-cuc-dau-la/150.jpg?1585206132" alt="">
                                    </div>
                                    <div class="content__section1-read-content">
                                        <div class="content__section1-main-item-title text">Bán Tiên</div>
                                        <div class="content__section1-read-chap">
                                            Đã Đọc: 12/615
                                            <i class="fas fa-trash"></i>
                                        </div>
                                    </div>
                                    <a href="" class="content__section1-read-continue">Đọc Tiếp</a>
                                </div>
                                <div class="content__section1-read-item">
                                    <div class="content__section1-read-img">
                                        <img src="https://static.cdnno.com/poster/dau-la-dai-luc-iv-chung-cuc-dau-la/150.jpg?1585206132" alt="">
                                    </div>
                                    <div class="content__section1-read-content">
                                        <div class="content__section1-main-item-title text">Bán Tiên</div>
                                        <div class="content__section1-read-chap">
                                            Đã Đọc: 12/615
                                            <i class="fas fa-trash"></i>
                                        </div>
                                    </div>
                                    <a href="" class="content__section1-read-continue">Đọc Tiếp</a>
                                </div>
                                <div class="content__section1-read-item">
                                    <div class="content__section1-read-img">
                                        <img src="https://static.cdnno.com/poster/dau-la-dai-luc-iv-chung-cuc-dau-la/150.jpg?1585206132" alt="">
                                    </div>
                                    <div class="content__section1-read-content">
                                        <div class="content__section1-main-item-title text">Bán Tiên</div>
                                        <div class="content__section1-read-chap">
                                            Đã Đọc: 12/615
                                            <i class="fas fa-trash"></i>
                                        </div>
                                    </div>
                                    <a href="" class="content__section1-read-continue">Đọc Tiếp</a>
                                </div>
                                <div class="content__section1-read-item">
                                    <div class="content__section1-read-img">
                                        <img src="https://static.cdnno.com/poster/dau-la-dai-luc-iv-chung-cuc-dau-la/150.jpg?1585206132" alt="">
                                    </div>
                                    <div class="content__section1-read-content">
                                        <div class="content__section1-main-item-title text">Bán Tiên</div>
                                        <div class="content__section1-read-chap">
                                            Đã Đọc: 12/615
                                            <i class="fas fa-trash"></i>
                                        </div>
                                    </div>
                                    <a href="" class="content__section1-read-continue">Đọc Tiếp</a>
                                </div>

                                <!-- Không có truyện đã đọc  -->
                                <!-- <div class="content__section1-read-item no-read">
                                    <a href="" class="no-read-btn">Bắt đầu đọc truyện nào
                                        <div class="no-read-btn__block-icon">
                                            <div class="no-read-btn__icon">
                                                <i class="fas fa-arrow-right"></i>
                                            </div>
                                            <div class="no-read-btn__icon">
                                                <i class="fas fa-arrow-right"></i>
                                            </div>
                                        </div>
                                    </a>
                                </div> -->
                                <!-- chưa login  -->
                                <!-- <div class="content__section1-read-item no-login">
                                    <i class="fas fa-frown"></i> Bạn cần đăng nhập để sử dụng chức năng này
                                </div> -->
                            </div>
                        </div>
                        <div class="content__section1-bottom">
                            <div class="content__section-header">
                                <div class="content__section-title title">Hướng Dẫn</div>
                                <a href="" class="content__section-link link">Xem Tất Cả</a>
                            </div>

                            <div class="content__section1-guide">
                                <div class="content__section1-guide-item">
                                    <div class="icon-cricle"></div>
                                    <span>Làm sao để tăng điểm hâm mộ?</span>
                                </div>

                                <div class="content__section1-guide-item">
                                    <div class="icon-cricle"></div>
                                    <span>Đừng để bị trừ Exp  </span>
                                </div>
                                <div class="content__section1-guide-item">
                                    <div class="icon-cricle"></div>
                                    <span>Hoa tồn tại được bao lâu? </span>
                                </div>
                                <div class="content__section1-guide-item">
                                    <div class="icon-cricle"></div>
                                    <span>Làm sao đổi màu nền, cỡ chữ, font chữ</span>
                                </div>
                                <div class="content__section1-guide-item">
                                    <div class="icon-cricle"></div>
                                    <span>Làm sao để có Hoa?</span>
                                </div>
                                <div class="content__section1-guide-item">
                                    <div class="icon-cricle"></div>
                                    <span>Tôi muốn xem điểm hâm mộ của mình, vào đâu để xem?</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="content__section2">
                <div class="content__section-header">
                    <div class="content__section-title title">Mới Cập Nhập</div>
                    <a href="" class="content__section-link link">Xem Tất Cả</a>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="content__section2-item">
                            <div class="content__section2-item-category-block">
                                <div class="limit1 content__section2-item-category">Huyền Huyễn</div>
                            </div>
                            <div class="content__section2-item-name-block">
                                <div class="limit1 content__section2-item-name text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum laboriosam architecto quisquam libero, est laudantium illo ex rem eius commodi repudiandae esse placeat deleniti eos a aut cumque. Sit, ut!</div>
                            </div>
                            <div class="col-3">
                                <a href="" class="limit1 content__section2-item-name-chap text">	
                                    Chương 622: Dương Ngục kiện thứ nhất pháp</a>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-master">Dược Thiên Sầu</div>
                            </div>
                            <div class="col-1">
                                <div class="limit1 content__section2-item-user">Ngọc Đức</div>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-time">3 phút trước</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="content__section2-item">
                            <div class="content__section2-item-category-block">
                                <div class="limit1 content__section2-item-category">Huyền Huyễn</div>
                            </div>
                            <div class="content__section2-item-name-block">
                                <div class="limit1 content__section2-item-name text">Bán Tiên</div>
                            </div>
                            <div class="col-3">
                                <a href="" class="limit1 content__section2-item-name-chap text">	
                                    Chương 622: Dương Ngục kiện thứ nhất pháp</a>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-master">Dược Thiên Sầu</div>
                            </div>
                            <div class="col-1">
                                <div class="limit1 content__section2-item-user">Ngọc Đức</div>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-time">3 phút trước</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="content__section2-item">
                            <div class="content__section2-item-category-block">
                                <div class="limit1 content__section2-item-category">Huyền Huyễn</div>
                            </div>
                            <div class="content__section2-item-name-block">
                                <div class="limit1 content__section2-item-name text">Bán Tiên</div>
                            </div>
                            <div class="col-3">
                                <a href="" class="limit1 content__section2-item-name-chap text">	
                                    Chương 622: Dương Ngục kiện thứ nhất pháp</a>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-master">Dược Thiên Sầu</div>
                            </div>
                            <div class="col-1">
                                <div class="limit1 content__section2-item-user">Ngọc Đức</div>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-time">3 phút trước</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="content__section2-item">
                            <div class="content__section2-item-category-block">
                                <div class="limit1 content__section2-item-category">Huyền Huyễn</div>
                            </div>
                            <div class="content__section2-item-name-block">
                                <div class="limit1 content__section2-item-name text">Bán Tiên</div>
                            </div>
                            <div class="col-3">
                                <a href="" class="limit1 content__section2-item-name-chap text">	
                                    Chương 622: Dương Ngục kiện thứ nhất pháp</a>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-master">Dược Thiên Sầu</div>
                            </div>
                            <div class="col-1">
                                <div class="limit1 content__section2-item-user">Ngọc Đức</div>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-time">3 phút trước</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="content__section2-item">
                            <div class="content__section2-item-category-block">
                                <div class="limit1 content__section2-item-category">Huyền Huyễn</div>
                            </div>
                            <div class="content__section2-item-name-block">
                                <div class="limit1 content__section2-item-name text">Bán Tiên</div>
                            </div>
                            <div class="col-3">
                                <a href="" class="limit1 content__section2-item-name-chap text">	
                                    Chương 622: Dương Ngục kiện thứ nhất pháp</a>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-master">Dược Thiên Sầu</div>
                            </div>
                            <div class="col-1">
                                <div class="limit1 content__section2-item-user">Ngọc Đức</div>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-time">3 phút trước</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="content__section2-item">
                            <div class="content__section2-item-category-block">
                                <div class="limit1 content__section2-item-category">Huyền Huyễn</div>
                            </div>
                            <div class="content__section2-item-name-block">
                                <div class="limit1 content__section2-item-name text">Bán Tiên</div>
                            </div>
                            <div class="col-3">
                                <a href="" class="limit1 content__section2-item-name-chap text">	
                                    Chương 622: Dương Ngục kiện thứ nhất pháp</a>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-master">Dược Thiên Sầu</div>
                            </div>
                            <div class="col-1">
                                <div class="limit1 content__section2-item-user">Ngọc Đức</div>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-time">3 phút trước</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="content__section2-item">
                            <div class="content__section2-item-category-block">
                                <div class="limit1 content__section2-item-category">Huyền Huyễn</div>
                            </div>
                            <div class="content__section2-item-name-block">
                                <div class="limit1 content__section2-item-name text">Bán Tiên</div>
                            </div>
                            <div class="col-3">
                                <a href="" class="limit1 content__section2-item-name-chap text">	
                                    Chương 622: Dương Ngục kiện thứ nhất pháp</a>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-master">Dược Thiên Sầu</div>
                            </div>
                            <div class="col-1">
                                <div class="limit1 content__section2-item-user">Ngọc Đức</div>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-time">3 phút trước</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="content__section2-item">
                            <div class="content__section2-item-category-block">
                                <div class="limit1 content__section2-item-category">Huyền Huyễn</div>
                            </div>
                            <div class="content__section2-item-name-block">
                                <div class="limit1 content__section2-item-name text">Bán Tiên</div>
                            </div>
                            <div class="col-3">
                                <a href="" class="limit1 content__section2-item-name-chap text">	
                                    Chương 622: Dương Ngục kiện thứ nhất pháp</a>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-master">Dược Thiên Sầu</div>
                            </div>
                            <div class="col-1">
                                <div class="limit1 content__section2-item-user">Ngọc Đức</div>
                            </div>
                            <div class="col-2">
                                <div class="limit1 content__section2-item-time">3 phút trước</div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>

            <div class="content__section3">
                <div class="row justify-content-center">
                    <div class="col-12 col-md-6 col-lg-4 col-xl-4">
                        <div class="content__section3-block content__section3-block1">
                            <div class="content__section-header">
                                <div class="content__section-title title">Đọc Nhiều Tuần</div>
                                <a href="" class="content__section-link link">Xem Tất Cả</a>
                            </div>
                            <div class="content__section3-list">
                                <div class="content__section3-item especially">
                                    <div class="content__section3-item-rank">
                                        <div class="badge-rank">
                                            <i class="fas fa-certificate"></i>
                                        </div>
                                    </div>
                                    <div class="content__section3-item-main">
                                        <div class="content__section3-item-title">
                                            <span class="limit1 text">Đỉnh Cấp Khí Vận, Lặng Lẽ Tu</span>
                                        </div>
                                        <div class="content__section3-item-view d-flex">
                                            <span class="limit1">455,555</span>
                                            <i class="fas fa-glasses"></i>
                                        </div>
                                        <div class="content__section3-item-master d-flex">
                                            <i class="fas fa-user-edit"></i>
                                            <span class="limit1">Nhậm Ngã Tiếu</span>
                                        </div>
                                        <div class="content__section3-item-category d-flex">
                                            <i class="fas fa-book"></i>
                                            Tiên Hiệp
                                        </div>
                                    </div>
                                    <div class="content__section3-item-img">
                                        <img src="https://static.cdnno.com/poster/dinh-cap-khi-van-lang-le-tu-luyen-ngan-nam/150.jpg?1614159439" alt="">
                                    </div>
                                </div>
                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        <div class="badge-rank silver">
                                            <i class="fas fa-certificate"></i>
                                        </div>
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>
                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        <div class="badge-rank cu">
                                            <i class="fas fa-certificate"></i>
                                        </div>
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        4
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        5
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        6
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        7
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        8
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        9
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        10
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4 col-xl-4">
                        <div class="content__section3-block content__section3-block2">
                            <div class="content__section-header">
                                <div class="content__section-title title">Thịnh Hành Tuần</div>
                                <a href="" class="content__section-link link">Xem Tất Cả</a>
                            </div>
                            <div class="content__section3-list">
                                <div class="content__section3-item especially">
                                    <div class="content__section3-item-rank">
                                        <div class="badge-rank">
                                            <i class="fas fa-certificate"></i>
                                        </div>
                                    </div>
                                    <div class="content__section3-item-main">
                                        <div class="content__section3-item-title">
                                            <span class="limit1 text">Đỉnh Cấp Khí Vận, Lặng Lẽ Tu</span>
                                        </div>
                                        <div class="content__section3-item-view d-flex">
                                            <span class="limit1">455,555</span>
                                            <i class="fas fa-glasses"></i>
                                        </div>
                                        <div class="content__section3-item-master d-flex">
                                            <i class="fas fa-user-edit"></i>
                                            <span class="limit1">Nhậm Ngã Tiếu</span>
                                        </div>
                                        <div class="content__section3-item-category d-flex">
                                            <i class="fas fa-book"></i>
                                            Tiên Hiệp
                                        </div>
                                    </div>
                                    <div class="content__section3-item-img">
                                        <img src="https://static.cdnno.com/poster/dinh-cap-khi-van-lang-le-tu-luyen-ngan-nam/150.jpg?1614159439" alt="">
                                    </div>
                                </div>
                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        <div class="badge-rank silver">
                                            <i class="fas fa-certificate"></i>
                                        </div>
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>
                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        <div class="badge-rank cu">
                                            <i class="fas fa-certificate"></i>
                                        </div>
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        4
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        5
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        6
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        7
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        8
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        9
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        10
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-6 col-lg-4 col-xl-4">
                        <div class="content__section3-block content__section3-block3">
                            <div class="content__section-header">
                                <div class="content__section-title title">Đề Cử Tuần</div>
                                <a href="" class="content__section-link link">Xem Tất Cả</a>
                            </div>
                            <div class="content__section3-list">
                                <div class="content__section3-item especially">
                                    <div class="content__section3-item-rank">
                                        <div class="badge-rank">
                                            <i class="fas fa-certificate"></i>
                                        </div>
                                    </div>
                                    <div class="content__section3-item-main">
                                        <div class="content__section3-item-title">
                                            <span class="limit1 text">Đỉnh Cấp Khí Vận, Lặng Lẽ Tu</span>
                                        </div>
                                        <div class="content__section3-item-view d-flex">
                                            <span class="limit1">455,555</span>
                                            <i class="fas fa-glasses"></i>
                                        </div>
                                        <div class="content__section3-item-master d-flex">
                                            <i class="fas fa-user-edit"></i>
                                            <span class="limit1">Nhậm Ngã Tiếu</span>
                                        </div>
                                        <div class="content__section3-item-category d-flex">
                                            <i class="fas fa-book"></i>
                                            Tiên Hiệp
                                        </div>
                                    </div>
                                    <div class="content__section3-item-img">
                                        <img src="https://static.cdnno.com/poster/dinh-cap-khi-van-lang-le-tu-luyen-ngan-nam/150.jpg?1614159439" alt="">
                                    </div>
                                </div>
                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        <div class="badge-rank silver">
                                            <i class="fas fa-certificate"></i>
                                        </div>
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>
                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        <div class="badge-rank cu">
                                            <i class="fas fa-certificate"></i>
                                        </div>
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        4
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        5
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        6
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        7
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        8
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        9
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>

                                <div class="content__section3-item">
                                    <div class="content__section3-item-rank">
                                        10
                                    </div>
                                    <div class="content__section3-item-main d-flex">
                                        <div class="limit1 content__section3-item-title text">Coi Mắt Đi Nhầm Bàn, Ta Bị Đối</div>
                                        <div class="limit1 content__section3-item-view">225,666</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="content__section1 content__section4">
                <div class="row">
                    <div class="col-12 col-lg-8 col-xl-8 section1-left order-1">
                        <div class="content__section-header">
                            <div class="content__section-title title">Mới Đăng</div>
                            <a href="" class="content__section-link link">Xem Tất Cả</a>
                        </div>

                        <div class="content__section1-main">
                            <div class="row">
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <div class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/cai-nay-vo-thanh-sieu-co-to-chat/150.jpg?1639326714" alt="">
                                        </div>
                                        <div class="content__section1-main-item-content">
                                            <div class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</div>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <div class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/cai-nay-vo-thanh-sieu-co-to-chat/150.jpg?1639326714" alt="">
                                        </div>
                                        <div class="content__section1-main-item-content">
                                            <div class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</div>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <div class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/cai-nay-vo-thanh-sieu-co-to-chat/150.jpg?1639326714" alt="">
                                        </div>
                                        <div class="content__section1-main-item-content">
                                            <div class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</div>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <div class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/cai-nay-vo-thanh-sieu-co-to-chat/150.jpg?1639326714" alt="">
                                        </div>
                                        <div class="content__section1-main-item-content">
                                            <div class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</div>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <div class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/cai-nay-vo-thanh-sieu-co-to-chat/150.jpg?1639326714" alt="">
                                        </div>
                                        <div class="content__section1-main-item-content">
                                            <div class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</div>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <div class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/cai-nay-vo-thanh-sieu-co-to-chat/150.jpg?1639326714" alt="">
                                        </div>
                                        <div class="content__section1-main-item-content">
                                            <div class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</div>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <div class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/cai-nay-vo-thanh-sieu-co-to-chat/150.jpg?1639326714" alt="">
                                        </div>
                                        <div class="content__section1-main-item-content">
                                            <div class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</div>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                                    <div class="content__section1-main-item">
                                        <div class="content__section1-main-item-img">
                                            <img src="https://static.cdnno.com/poster/cai-nay-vo-thanh-sieu-co-to-chat/150.jpg?1639326714" alt="">
                                        </div>
                                        <div class="content__section1-main-item-content">
                                            <div class="content__section1-main-item-title text">Tu Luyện Theo Đấu Phá Thương Khung Bắt Đầu</div>
                                            <div class="content__section1-main-item-demo">
                                                Hệ thống nơi tay, thế giới ta có, thiếu niên người mang vạn năng hệ thống, theo Đấu Phá Thương Khung bắt đầu tu luyện, đây là một người hiện đại tại dị giới tu hành cố sự. . .
                                            </div>
                                            <div class="content__section1-main-item-footer">
                                                <div class="content__section1-main-item-master">
                                                    <i class="fas fa-user-edit"></i>
                                                    Giang Hồ Hữu Tửu
                                                </div>
                                                <div class="content__section1-main-item-category btn">Đồng Nhân</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 d-none d-lg-block section1-right order-0">
                        <div class="content__section1-top">
                            <div class="content__section-header">
                                <div class="content__section-title title">Mới Đánh Giá</div>
                                <a href="" class="content__section-link link">Xem Tất Cả</a>
                            </div>

                            <div class="content__section4-assess">
                                <div class="content__section4-assess-item">
                                    <div class="content__section4-assess-item-top">
                                        <div class="content__section4-assess-item-avt" style="background-image: url(https://static.cdnno.com/user/default/50.jpg);"></div>
                                        <div class="content__section4-assess-item-information">
                                            <div class="content__section4-assess-item-nameUser">
                                                <span style="font-weight: 600; color: #333;margin-right: 5px;" class="limit1">Boooom</span>
                                                đánh giá
                                            </div>
                                            <div class="content__section4-assess-item-nameProduct limit1">Toàn Chức Nghệ Thuật Gia</div>
                                        </div>
                                        <div class="content__section4-assess-item-point">5.00</div>
                                    </div>
                                    <div class="content__section4-assess-item-bottom limit3">
                                        thật là đặc sắc cốt truyện, main tư tưởng hiện đại nên lúc bth k thích ứng đc thế giới mới, cơ mà lúc có quyền hành thì lãnh địa sẽ phát triển rất tốt. à
                                    </div>
                                </div>
                                <div class="content__section4-assess-item">
                                    <div class="content__section4-assess-item-top">
                                        <div class="content__section4-assess-item-avt" style="background-image: url(https://static.cdnno.com/user/default/50.jpg);"></div>
                                        <div class="content__section4-assess-item-information">
                                            <div class="content__section4-assess-item-nameUser">
                                                <span style="font-weight: 600; color: #333;margin-right: 5px;" class="limit1">Boooom</span>
                                                đánh giá
                                            </div>
                                            <div class="content__section4-assess-item-nameProduct limit1">Toàn Chức Nghệ Thuật Gia</div>
                                        </div>
                                        <div class="content__section4-assess-item-point">5.00</div>
                                    </div>
                                    <div class="content__section4-assess-item-bottom limit3">
                                        thật là đặc sắc cốt truyện, main tư tưởng hiện đại nên lúc bth k thích ứng đc thế giới mới, cơ mà lúc có quyền hành thì lãnh địa sẽ phát triển rất tốt. à
                                    </div>
                                </div>
                                <div class="content__section4-assess-item">
                                    <div class="content__section4-assess-item-top">
                                        <div class="content__section4-assess-item-avt" style="background-image: url(https://static.cdnno.com/user/default/50.jpg);"></div>
                                        <div class="content__section4-assess-item-information">
                                            <div class="content__section4-assess-item-nameUser">
                                                <span style="font-weight: 600; color: #333;margin-right: 5px;" class="limit1">Boooom</span>
                                                đánh giá
                                            </div>
                                            <div class="content__section4-assess-item-nameProduct limit1">Toàn Chức Nghệ Thuật Gia</div>
                                        </div>
                                        <div class="content__section4-assess-item-point">5.00</div>
                                    </div>
                                    <div class="content__section4-assess-item-bottom limit3">
                                        thật là đặc sắc cốt truyện, main tư tưởng hiện đại nên lúc bth k thích ứng đc thế giới mới, cơ mà lúc có quyền hành thì lãnh địa sẽ phát triển rất tốt. à
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer">
            <div class="row">
                <div class="col-12">
                    <a href="index.html" class="footer__logo logo">
                        <img src="https://metruyenchu.com/assets/images/logo.png?260329" alt="">
                    </a>
                </div>
                <div class="col-12">
                    <div class="footer__introduce limit3">
                        Mê Truyện Chữ là nền tảng mở trực tuyến, miễn phí đọc truyện chữ được convert hoặc dịch kỹ lưỡng, do các converter và dịch giả đóng góp, rất nhiều truyện hay và nổi bật được cập nhật nhanh nhất với đủ các thể loại tiên hiệp, kiếm hiệp, huyền ảo ,...
                    </div>
                </div>
                <div class="col-12">
                    <a href="" class="footer__btn">
                        <img src="https://metruyenchu.com/assets/images/app-store.png?260329" alt="">
                    </a>
                    <a href="" class="footer__btn">
                        <img src="https://metruyenchu.com/assets/images/google-play.png?260329" alt="">
                    </a>
                </div>
                <div class="col-12">
                    <div class="footer__link link ">Điều Khoản Dịch Vụ</div>
                    <div class="footer__link link">Chính Sách Bảo Mật</div>
                    <div class="footer__link link">Về Bản Quyền</div>
                    <div class="footer__link link">Hướng Dẫn Sử Dụng</div>
                </div>
            </div>
        </footer>
    </div>
</div>