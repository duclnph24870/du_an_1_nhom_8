<?php 
    header('location: user/trangchu/index.php');
?>